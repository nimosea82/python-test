<template>
  <div id="success">
    <div id="success-info">
      <h2>提交成功 感谢您的参与!</h2>
    </div>
  </div>
</template>

<script>
  export default {
    name: "success"
  }
</script>

<style scoped>
  #success-info{
    text-align: center;
    padding-top: 30vh;
  }
</style>