<template>
  <div id="npsSelector">

  </div>
</template>

<script>
  export default {
    name: "npsSelector"
  }
</script>

<style scoped>

</style>